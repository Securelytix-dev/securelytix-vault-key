{{- define "dev-sdk.name" -}}
{{- .Chart.Name }}
{{- end }}

{{- define "dev-sdk.fullname" -}}
{{- printf "%s-%s" .Release.Name .Chart.Name | trunc 63 | trimSuffix "-" }}
{{- end }}

{{- define "dev-sdk.labels" -}}
helm.sh/chart: {{ .Chart.Name }}-{{ .Chart.Version }}
{{ include "dev-sdk.selectorLabels" . }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{- define "dev-sdk.selectorLabels" -}}
app.kubernetes.io/name: {{ include "dev-sdk.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}
